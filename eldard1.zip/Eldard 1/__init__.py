# YELLOW MAX POOL Trading Bot Package
# This file makes the directory a Python package

# Version information
__version__ = '1.0.0'
__author__ = 'YELLOW MAX POOL Team'